<template>
    <header class="sticky top-0 bg-primary shadow-lg">
        <nav class="container flex flex-col sm:flex-row items-center gap-4 text-secondary py-6">
            <div class="flex flex-1 justify-center mr-auto items-center gap-3">
                <img class="w-12 h-12" src="../assets/images/cake.png" alt="cake day logo">
                <p class="text-2xl">Cake Days App</p>
            </div>
        </nav>
    </header>
</template>

<script setup>

</script>