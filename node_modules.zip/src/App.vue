<script setup>
import Navbar from "./components/Navbar.vue";
import MainContent from "./components/MainContent.vue";
</script>

<template>
	<div class="flex flex-col min-h-screen font-Roboto">
		<Navbar />
		<MainContent />
	</div>
</template>

<style scoped>

</style>
